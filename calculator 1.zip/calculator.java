package program1;
import java.util.*;
public class calculator {
	public void operation(float num1,int num2,char operator)
	{
		double res;
		switch(operator)
        {
        case '+':
        	res= num1 + num2;
        	System.out.println("Result is"+res);
            break;

        case '-':
        	res = num1 - num2;
        	System.out.println("Result is"+res);
            break;

        case '*':
        	res = num1 * num2;
        	System.out.println("Result is"+res);
            break;

        case '/':
        	res = num1 / num2;
        	System.out.println("Result is"+res);
            break;
        default:
            System.out.printf("You have entered wrong operator");
            break;
        }
		
	}
	public static void main(String[] args){
		try(Scanner x =new Scanner(System.in))
		{
		System.out.println("Enter first number");
		float a=(float)x.nextFloat();
		int  w=(int)a+10;
		System.out.println("Enter second number");
		System.out.println(w);
		System.out.println("Choose the operator");
		char op=x.next().charAt(0);
		calculator ob=new calculator();
		ob.operation(a, w,op);
		}
	}

}
